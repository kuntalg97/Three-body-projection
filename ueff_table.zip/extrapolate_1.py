# Kuntal Ghosh
# Code to extrapolate data

import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import InterpolatedUnivariateSpline

filename = 'ueff.dat'
n_lines = len(open(filename).readlines())
n_total = 66

# given values
xi, yi = np.loadtxt(filename, unpack=True)

# positions to inter/extrapolate
x = np.linspace(2.4, 3.7, n_total)

# spline order: 1 linear, 2 quadratic, 3 cubic ... 
order = 1 # quadratic splines work best for extrapolating pair potentials and linear splines for forces

# do inter/extrapolation
s = InterpolatedUnivariateSpline(xi, yi, k=order)
y = s(x)

out_file = open ('ueff_extrap.dat', 'w')

for i in range (1,n_total+1):
    out_file.write ("%16.6f%16.6f\n"%(x[i-1],y[i-1]))

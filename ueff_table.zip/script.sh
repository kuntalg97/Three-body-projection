#!/bin/bash

# Requirement - 1_1.dat file (from 3BFM) and ueff.dat (from projection code, done separately)

gfortran -O3 pot.f90 -o pot.exe
./pot.exe #generates pairpot.dat

python extrapolate_1.py #extrapolates ueff.dat to ueff_extrap.dat

gfortran -O3 combine.f90 -o combine.exe
./combine.exe #combines to get u_combine.dat

sed -i -e 1,4d u_combine.dat # start only from 2.4

python extrapolate_2.py #extrapolates u_combine.dat to u_extrap.dat

# Generates final table
gfortran -O3 pot_table.f90 -o tab.exe
./tab.exe
